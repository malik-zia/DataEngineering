import requests
import pandas as pd

# Step 1: Fetch user data from the JSONPlaceholder API endpoint /users
api_url = "https://jsonplaceholder.typicode.com/users"
response = requests.get(api_url)

# Check if the request was successful (status code 200)
if response.status_code == 200:
    user_data = response.json()
else:
    print("Failed to fetch user data from the API")
    user_data = []

# Step 2: Extract relevant fields from the API response
relevant_user_data = []
for user in user_data:
    relevant_user_data.append({
        'customer_id': user['id'],
        'name': user['name'],
        'username': user['username'],
        'email': user['email'],
        'lat': user['address']['geo']['lat'],
        'lng': user['address']['geo']['lng']
    })

# Step 3: Read the sales data from the CSV file 
#"AIQ_Data_Engineer_Assignment_Sales_data.csv"
sales_data_path = r'C:\Users\ZZ00F0808\Desktop\AIQ_Data_Engineer\AIQ_Data_Engineer_Assignment_Sales_data.csv' 
sales_data = pd.read_csv(sales_data_path)

# Step 4: Merge the user data with the sales data based on the customer_id field
merged_data = pd.merge(sales_data, pd.DataFrame(relevant_user_data), on='customer_id', how='left')

# Print the first few rows of the merged data
# print(merged_data.head())

# Print the first few rows of the merged data
print(merged_data)

# Optionally, you can save the merged data to a new CSV file
merged_data.to_csv("merged_sales_data.csv", index=False)
 