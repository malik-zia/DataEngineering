import requests
import pandas as pd

# Function to fetch weather data for a given latitude and longitude
def fetch_weather_data(lat, lon, api_key):
    url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={api_key}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Failed to fetch weather data for lat: {lat}, lon: {lon}")
        return None

# Function to extract relevant weather information
def extract_weather_info(weather_data):
    if weather_data:
        temperature_kelvin = weather_data.get('main', {}).get('temp')
        temperature_celsius = temperature_kelvin - 273.15 if temperature_kelvin is not None else None
        weather_conditions = weather_data.get('weather', [])[0].get('description')
        return {
            'temperature': temperature_celsius,
            'weather_conditions': weather_conditions
        }
    else:
        return None

# Read the sales data
sales_data = pd.read_csv("merged_sales_data.csv")

# Get your OpenWeatherMap API key
api_key = '7cf9385efe41f85d2b376e164328ea36'  # Replace with your actual API key

# Fetch weather data for each sale location and add it to the DataFrame
weather_info_list = []
for index, row in sales_data.iterrows():
    lat, lon = row['lat'], row['lng']
    weather_data = fetch_weather_data(lat, lon, api_key)
    weather_info = extract_weather_info(weather_data)
    weather_info_list.append(weather_info)

# Add weather information to the DataFrame
weather_info_df = pd.DataFrame(weather_info_list)
sales_data_with_weather = pd.concat([sales_data, weather_info_df], axis=1)

# Save the final dataset to a new CSV file
sales_data_with_weather.to_csv("sales_data_with_weather.csv", index=False)
