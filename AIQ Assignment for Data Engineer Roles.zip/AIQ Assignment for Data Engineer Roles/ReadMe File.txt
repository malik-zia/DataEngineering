
-- Sales Data Pipeline

Follow these instructions to set up and run the data pipeline on your local machine.

-- Environment Setup Instructions
1. Python: Ensure you have Python installed.
   Install required libraries: Install necessary libraries (pandas, requests, sqlalchemy, etc.) using pip.
   bash
   pip install pandas requests sqlalchemy
   Docker should be installed on your system if you are going to do Dockerization (Dockerization is optional in this assignment).
   
2. Loading CSV File, Place your CSV file containing sales data in the project directory.
   Run the script:
   
   python Fetch_UserData_JPH.py
   after successful completion of first script run the 2nd script,
   python Fetch_OWM_Data_with_UsersSales.py

3. Data Transformation Steps
	a. Load sales data from CSV.
	b. Fetch user data from JSONPlaceholder API.
	c. Merge sales data with user data.
	d. Fetch weather data for each sale location.
	
4. Aggregations and Manipulations
	a. Run the aggregations_on_merged_dataset.py script to perform data aggregations and manipulations.
or
	b. Perform data aggregations and manipulations using Oracle SQL.

5. Dockerization (Optional)

    Dockerize the solution for easy deployment using Docker:
	
	docker build -t aiq-sales-pipeline .
	docker run -d --name aiq-sales-container aiq-sales-pipeline
	
6. Database Schema and Table Creation

    a. The database schema and table creation SQL scripts are available in the database directory.
    b. Execute the SQL scripts in your Oracle database environment to create the required tables for storing the transformed data.	
