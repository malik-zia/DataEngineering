import requests
import pandas as pd
# Read the merged dataset with weather information
# merged_data = pd.read_csv("sales_data_with_weather.csv")

merged_data_path = r'C:\Users\ZZ00F0808\Desktop\AIQ_Data_Engineer\sales_data_with_weather.csv'
merged_data = pd.read_csv(merged_data_path)

# Calculate total sales amount per customer
total_sales_per_customer = merged_data.groupby('customer_id')['price'].sum()

# Determine the average order quantity per product
average_order_quantity_per_product = merged_data.groupby('product_id')['quantity'].mean()

# Identify the top-selling products
top_selling_products = merged_data.groupby('product_id')['quantity'].sum().nlargest(5)

# Identify the top customers
top_customers = merged_data.groupby('customer_id')['quantity'].sum().nlargest(5)

# Analyze sales trends over time
merged_data['order_date'] = pd.to_datetime(merged_data['order_date'])
monthly_sales_trend = merged_data.groupby(merged_data['order_date'].dt.to_period('M'))['price'].sum()

# Include weather data in the analysis
average_sales_per_weather_condition = merged_data.groupby('weather_conditions')['price'].mean()

# Save the results to CSV files
total_sales_per_customer.to_csv("total_sales_per_customer.csv", header=True)
average_order_quantity_per_product.to_csv("average_order_quantity_per_product.csv", header=True)
top_selling_products.to_csv("top_selling_products.csv", header=True)
top_customers.to_csv("top_customers.csv", header=True)
monthly_sales_trend.to_csv("monthly_sales_trend.csv", header=True)
average_sales_per_weather_condition.to_csv("average_sales_per_weather_condition.csv", header=True)


# Print the results
print("Total sales amount per customer:\n", total_sales_per_customer)
print("\nAverage order quantity per product:\n", average_order_quantity_per_product)
print("\nTop selling products:\n", top_selling_products)
print("\nTop customers:\n", top_customers)
print("\nMonthly sales trend:\n", monthly_sales_trend)
print("\nAverage sales per weather condition:\n", average_sales_per_weather_condition)
